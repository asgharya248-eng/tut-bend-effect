# SPDX-License-Identifier: GPL-3.0-or-later
# Tut Bend Effect - Geometry Nodes add-on generated from "tut bend .blend"
# The node trees are shipped as-is inside assets/tut_bend_effect.blend,
# so all nodes, values and links are byte-for-byte identical to the source.

bl_info = {
    "name": "Tut Bend Effect",
    "author": "Generated from tut bend .blend",
    "version": (1, 0, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Tut Bend",
    "description": "Bend effect made with Geometry Nodes, packaged from the source .blend without touching node links",
    "category": "Node",
}

import os

import bpy

ROOT_GROUP = "Tut Bend Effect"
SUB_GROUP = "NodeGroup"
PATH_OBJECT = "NurbsPath"


def _asset_path():
    return os.path.join(os.path.dirname(__file__), "assets", "tut_bend_effect.blend")


def _load_asset():
    """Append node groups + path object from the bundled .blend."""
    filepath = _asset_path()
    if not os.path.isfile(filepath):
        raise RuntimeError("Add-on asset file missing: %s" % filepath)

    with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
        wanted_objects = []
        wanted_groups = []
        if PATH_OBJECT not in bpy.data.objects:
            wanted_objects.append(PATH_OBJECT)
        if ROOT_GROUP not in bpy.data.node_groups:
            wanted_groups.append(ROOT_GROUP)
        if SUB_GROUP not in bpy.data.node_groups:
            wanted_groups.append(SUB_GROUP)
        data_to.objects = wanted_objects
        data_to.node_groups = wanted_groups

    root = bpy.data.node_groups.get(ROOT_GROUP)
    if root is None:
        raise RuntimeError("Could not load node group '%s' from the add-on." % ROOT_GROUP)
    root.use_fake_user = True
    sub = bpy.data.node_groups.get(SUB_GROUP)
    if sub is not None:
        sub.use_fake_user = True
    for ob in data_to.objects:
        if ob is None:
            continue
        ob.use_fake_user = True
        if ob.data:
            ob.data.use_fake_user = True
        if ob.name not in bpy.context.scene.collection.objects:
            bpy.context.scene.collection.objects.link(ob)
            ob.hide_render = True
            ob.hide_viewport = True
    return root


class TUTBEND_OT_add(bpy.types.Operator):
    bl_idname = "tutbend.add_effect"
    bl_label = "Add Tut Bend Effect"
    bl_description = "Add the Geometry Nodes bend modifier to the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type in {
            "MESH", "CURVE", "SURFACE", "META", "FONT", "POINTCLOUD", "VOLUME",
            "GREASEPENCIL", "EMPTY",
        }

    def execute(self, context):
        ob = context.active_object
        root = bpy.data.node_groups.get(ROOT_GROUP) or _load_asset()
        mod = ob.modifiers.get("Tut Bend Effect")
        if mod is None:
            mod = ob.modifiers.new(name="Tut Bend Effect", type="NODES")
        mod.node_group = root
        return {"FINISHED"}


class TUTBEND_OT_remove(bpy.types.Operator):
    bl_idname = "tutbend.remove_effect"
    bl_label = "Remove Effect"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        ob = context.active_object
        for mod in list(ob.modifiers):
            if mod.type == "NODES" and mod.node_group and mod.node_group.name == ROOT_GROUP:
                ob.modifiers.remove(mod)
        return {"FINISHED"}


class TUTBEND_OT_edit(bpy.types.Operator):
    bl_idname = "tutbend.edit_nodes"
    bl_label = "Open Node Editor"
    bl_description = "Open the original node tree in a Geometry Nodes editor"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        root = bpy.data.node_groups.get(ROOT_GROUP) or _load_asset()
        for area in context.screen.areas:
            if area.type == "NODE_EDITOR":
                space = area.spaces.active
                space.node_tree = root
                space.tree_type = "GeometryNodeTree"
                area.tag_redraw()
                return {"FINISHED"}
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    for region in area.regions:
                        if region.type == "WINDOW":
                            with context.temp_override(window=window, area=area, region=region):
                                bpy.ops.screen.area_split(direction="VERTICAL", factor=0.5)
                            new_area = window.screen.areas[-1]
                            new_area.type = "NODE_EDITOR"
                            space = new_area.spaces.active
                            space.node_tree = root
                            space.tree_type = "GeometryNodeTree"
                            return {"FINISHED"}
        self.report({"WARNING"}, "No 3D viewport found")
        return {"CANCELLED"}


class TUTBEND_PT_panel(bpy.types.Panel):
    bl_label = "Tut Bend Effect"
    bl_idname = "TUTBEND_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tut Bend"

    def draw(self, context):
        layout = self.layout
        ob = context.active_object
        has_mod = ob is not None and any(
            m.type == "NODES" and m.node_group and m.node_group.name == ROOT_GROUP
            for m in ob.modifiers
        )
        if ROOT_GROUP not in bpy.data.node_groups:
            layout.label(text="Asset loads on first use.", icon="INFO")
        col = layout.column(align=True)
        col.operator(TUTBEND_OT_add.bl_idname, icon="NODETREE")
        if has_mod:
            col.operator(TUTBEND_OT_remove.bl_idname, icon="X")
        layout.operator(TUTBEND_OT_edit.bl_idname, icon="CONSOLE")
        if has_mod:
            mod = next(m for m in ob.modifiers if m.type == "NODES"
                       and m.node_group and m.node_group.name == ROOT_GROUP)
            layout.separator()
            layout.prop(mod, "show_expanded", text="Show Inputs on Modifier")


classes = (TUTBEND_OT_add, TUTBEND_OT_remove, TUTBEND_OT_edit, TUTBEND_PT_panel)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
